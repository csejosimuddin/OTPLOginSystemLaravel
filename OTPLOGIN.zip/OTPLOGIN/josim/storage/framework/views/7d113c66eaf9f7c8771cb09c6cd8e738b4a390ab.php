<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row">
      <div class="col-lg-4">
         <div class="card px-3 py-3">
            <div class="card-header bg-success">
               Add Category Form
            </div>

            <!-- এর মাধমে success alert টা পাবো -->
            <?php if(session('status')): ?> 
            <!-- status এটা addproductinsert Conroller থেকে আসছে -->
            <div class="alert alert-success">
               <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <?php if($errors->all()): ?>
            <div class="alert alert-danger">
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

          
            <form action="<?php echo e(url('/add/category/insert')); ?>" method="post">
               <!--  <?php echo e(url('/add/product/insert')); ?> এটা Route থেকে আসছে -->
               <!-- ফরমের ডাটা ডাটাবেসে পাঠাইতে হলে <?php echo csrf_field(); ?> লিখতেই হবে  -->
               <?php echo csrf_field(); ?>
               <div class="form-group">
                  <label>Category Name</label>
                  <input type="text" class="form-control" name="category_name" placeholder="Enter Category Name">
               </div>

               <button type="submit" class="btn btn-info">Add Category</button>
            </form>
         </div>
      </div>
      <div class="col-lg-8">

         <table class="table table-bordered">
            <thead>
               <tr>
                  <th>SL.NO</th>
                  <th>Category Name</th>
               </tr>
            </thead>
            <tbody>
               <!-- এর মাধমে ডাটাবেস থেকে ডাটাগুলো দেখাছে -->
               <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr>
               
                  <td><?php echo e($category->category_id); ?></td>
             
                  <td><?php echo e($category->created_at); ?></td>
               
                  

      
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

               <tr class="text-center">
                  <td colspan="6"> No Data Available</td>
               </tr>
               <?php endif; ?>
            </tbody>
         </table>

      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim Uddin\Desktop\CIT\josim\resources\views/category/view.blade.php ENDPATH**/ ?>