<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row">
      <div class="col-lg-4">
         <div class="card px-3 py-3">
            <div class="card-header bg-success">
               Add Coupons 
            </div>

            </div>

            <?php if($errors->all()): ?>
            <div class="alert alert-danger">
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(url('/add/coupon/insert')); ?>" method="post">
               <?php echo csrf_field(); ?>

               <div class="form-group">
                  <label>Coupon Name</label>
                  <input type="text" class="form-control" name="coupon_name" placeholder="Enter Coupon Name" value="<?php echo e(old('coupon_name')); ?>">

                  <label>coupon percentage</label>
                  <input type="text" class="form-control" name="coupon_percentage" placeholder="Enter Ccoupon percentage" value="<?php echo e(old('coupon_percentage')); ?>">

                  <label>valid till</label>
                  <input type="date" class="form-control" name="valid_till" value="<?php echo e(old('valid_till')); ?>">

               </div>
               
              
               <button type="submit" class="btn btn-info">Submit</button>
            </form>
         </div>

         <div class="col-lg-8">

<table class="table table-bordered">
   <thead>
      <tr>
         <th>SL.NO</th>
         <th>Coupon Name</th>
         <th>coupon percentage</th>
         <th>valid till</th>
      </tr>
   </thead>
   <tbody>
   <?php $__currentLoopData = $couponDatashow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $couponDatashow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
   <td><?php echo e($loop->index+1); ?></td>
   <td><?php echo e($couponDatashow->coupon_name); ?></td>
   <td><?php echo e($couponDatashow->coupon_percentage); ?></td>
   <td><?php echo e($couponDatashow->valid_till); ?></td>
     
   </tr>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
   </tbody>
</table>
</div>

      </div>
      
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josim Uddin\Desktop\CITClass\josim\resources\views/Product/coupon/viewcopun.blade.php ENDPATH**/ ?>