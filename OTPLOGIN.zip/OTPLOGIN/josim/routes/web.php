<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// রেজিস্টেশন করার জনে
Route::post('newregister', 'UserController@register')->name('newregister');


    // মোবাইল ও পাসওয়ার্ড দিয়ে লগিন করার জনে

Route::post('login', 'UserController@login')->name('newlogin');

 // OTP দিয়ে লগিন করার জনে
Route::get('loginWithOtp', function () {
    return view('auth/OtpLogin');
})->name('loginWithOtp');

 Route::post('loginWithOtp', 'UserController@loginWithOtp')->name('loginWithOtp');

// Otp Message দিয়ে লগিন করার জনে
 Route::post('sendOtp', 'UserController@sendOtp');